#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "menu.h"

void           //c'est bon
on_button_mod_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod1, *mod2, *mod3, *mod4;//*pInfo
menu u;
mod1=lookup_widget(objet,"mod1");
mod2=lookup_widget(objet,"mod2");
mod3=lookup_widget(objet,"mod3");
mod4=lookup_widget(objet,"combobox1");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(mod1)));
u.repas=gtk_combo_box_get_active(GTK_COMBO_BOX(mod4));
strcpy(u.menu,gtk_entry_get_text(GTK_ENTRY(mod2)));
u.dechet = atof(gtk_entry_get_text(GTK_ENTRY(mod3)));
modifier(u,"menu.txt");
//pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Menu bien modifié");
	//switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	//{
	//case GTK_RESPONSE_OK:
	//gtk_widget_destroy(pInfo);
	//break;
	//}
}







void
on_treeview_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar *id;
	menu u;
	GtkWidget *pInfo;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path))
        {
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,-1);
	strcpy(u.id,id);
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nsupprimer ce menu?");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_YES:
	gtk_widget_destroy(pInfo);
	supprimer(u,"menu.txt");
	afficher(treeview,"menu.txt");
	break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pInfo);
	break;                        //c'est bon
}	
}
}


void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windm, *windaf;
windaf=lookup_widget(objet,"windaf");       //c'est bon
windm=lookup_widget(objet,"windm");
windm=create_windm();
gtk_widget_show(windm);
}


void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windaj, *windaf;
windaf=lookup_widget(objet,"windaf");         //c'est bon
windaj=lookup_widget(objet,"windaj");
windaj=create_windaj();
gtk_widget_show(windaj);
}



void
on_meilleur_menu_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windbest, *windaf;
windaf=lookup_widget(objet,"windaf");         //c'est bon
windbest=lookup_widget(objet,"windbest");
windbest=create_windbest();
gtk_widget_show(windbest);
}


void
on_affichage_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview, *windaf;
windaf=lookup_widget(objet,"windaf");
gtk_widget_destroy(windaf);
windaf=lookup_widget(objet,"windaf");
windaf=create_windaf();
gtk_widget_show(windaf);
treeview=lookup_widget(windaf,"treeview");
afficher(treeview,"menu.txt");
}


void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windsup, *windaf;
windaf=lookup_widget(objet,"windaf");      //c'est bon
windsup=lookup_widget(objet,"winddsup");
windsup=create_windsup();
gtk_widget_show(windsup);
}




void  //c'est bon
on_checkid_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod1, *mod2, *mod3, *pInfo, *mod4;
menu p;
int a=0;
char ch[20], id[50];
FILE *f;
mod1=lookup_widget(objet,"mod1");
mod2=lookup_widget(objet,"mod2");
mod3=lookup_widget(objet,"mod3");
mod4=lookup_widget(objet,"combobox1");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(mod1)));
f = fopen("menu.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %d %s %f %d %d %d\n",p.id,&(p.repas),p.menu,&(p.dechet),&(p.d.j),&(p.d.m),&(p.d.a))!=EOF)
	{
		if(strcmp(p.id,id)==0){
			a=1;
			break;
                 }
	}
fclose(f);
}
if(a==1){
gtk_entry_set_text(GTK_ENTRY(mod2),p.menu);
sprintf(ch,"%.2f",p.dechet);
gtk_entry_set_text(GTK_ENTRY(mod3),ch);
gtk_combo_box_set_active(GTK_COMBO_BOX(mod4),p.repas);
}
else{
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Menu introuvable");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}
}


void
on_ines_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ne, *ss, *ie, *a, *b, *c ,*ibn;
GtkCalendar *jma;
menu u;
int day, month, year;
ne=lookup_widget(objet,"ne");
ss=lookup_widget(objet,"ss");
ie=lookup_widget(objet,"ie");
jma=lookup_widget(objet,"jma");//pointer sur calendrier 
a=lookup_widget(objet,"radiobutton1");//les toggles
b=lookup_widget(objet,"radiobutton2");
c=lookup_widget(objet,"radiobutton3");
ibn=lookup_widget(objet,"ibn");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(ne)));//copier entry a u.id
u.repas=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(a))?0:gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(b))?1:gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(c))?2:
strcpy(u.repas,gtk_entry_get_text(GTK_ENTRY(ss)));//entry2 a u.repas
u.dechet=atof(gtk_entry_get_text(GTK_ENTRY(ie)));//entry3 a u.dechet
ibn=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ibn));
gtk_calendar_get_date(GTK_CALENDAR(jma), &day, &month, &year);//lire calendrier
u.d.j=year;//structure sous structure date
u.d.m=month+1;
u.d.a=day;
ajouter(u,"menu.txt");
}



void
on_supprimerrr_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *sup1, *mod2, *mod3, *pInfo, *mod4;
menu p, u;
int a=0;
FILE *f;
sup1=lookup_widget(objet,"sup1");
strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(sup1)));
f = fopen("menu.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %d %s %f %d %d %d\n",p.id,&(p.repas),p.menu,&(p.dechet),&(p.d.j),&(p.d.m),&(p.d.a))!=EOF)
	{
		if(strcmp(p.id,u.id)==0){
			a=1;
			break;
                 }
	}
fclose(f);
}
if(a==1)
supprimer(u,"menu.txt");
else{
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Menu non existant");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}
}


void
on_retouraj_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windaj;
windaj=lookup_widget(objet,"windaj");
gtk_widget_destroy(windaj);
GtkWidget *windaf;
windaf=create_windaf();
   gtk_widget_show(windaf);
}


void
on_retourmod_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windmd;
windmd=lookup_widget(objet,"windmd");
gtk_widget_destroy(windmd);
GtkWidget *windaf;
windaf=create_windaf();
   gtk_widget_show(windaf);
}


void
on_retoursup_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windsup;
windsup=lookup_widget(objet,"windsup");
gtk_widget_destroy(windsup);
GtkWidget *windaf;
windaf=create_windaf();
   gtk_widget_show(windaf);
}


void
on_retourbest_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windbest;
windbest=lookup_widget(objet,"windbest");
gtk_widget_destroy(windbest);
GtkWidget *windaf;
windaf=create_windaf();
   gtk_widget_show(windaf);
}

//int g[4];

void
on_checksemone_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
//if (gtk_toggle_button_get_active(togglebutton))
//g[0]=1;
}


void
on_checksemtwo_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_checksemthree_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_checksemfour_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_bestbest_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{

}

