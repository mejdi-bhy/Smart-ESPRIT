#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "menu.h"
#include "callbacks.h"
#include <gtk/gtk.h>

enum
{
	ID,
	REPAS,
	MENU,
	DECHET,
	DATE,
        SEMAINE,
	COLUMNS,
};


void ajouter(menu u, char *fname){
GtkWidget *pQuestion, *pInfo;
FILE *f;
int b=0;
gpointer user_data;
menu p;
f=fopen(fname,"a+");//ya9ra 3alih bil p
if(f!=NULL)
{	while(fscanf(f,"%s %d %s %f %d %d %d %d\n",p.id,&(p.repas),p.menu,&(p.dechet),&(p.d.j),&(p.d.m),&(p.d.a),&(p.semaine))!=EOF)
	{	
		if(strcmp(u.id,p.id)==0)
		b++;
	}
	if(b==0){//si n'a pas trouver
	fprintf(f,"%s %d %s %f %d %d %d %d\n",u.id,u.repas,u.menu,u.dechet,u.d.j,u.d.m,u.d.a,u.semaine);
	pQuestion=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Menu est bien ajouté !");
	switch(gtk_dialog_run(GTK_DIALOG(pQuestion)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pQuestion);
	break;
	}
	}
	if(b!=0)
        {//si trouver
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_WARNING,GTK_BUTTONS_OK,"Menu déja existant !");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
	}
	fclose(f);
}
}

void modifier(menu u, char *fname){
menu p;
GtkWidget *pInfo;
gpointer user_data;
FILE *f, *g;
f=fopen(fname,"r");
g=fopen("dump.txt","w");
if(f==NULL||g==NULL)
{
	return;
}
else{
	while(fscanf(f,"%s %d %s %f %d %d %d %d\n",p.id,&(p.repas),p.menu,&(p.dechet),&(p.d.j),&(p.d.m),&(p.d.a),&(p.semaine))!=EOF)
	{
		if(strcmp(p.id,u.id)!=0)
			fprintf(g,"%s %d %s %.2f %d %d %d %d\n",p.id,p.repas,p.menu,p.dechet,p.d.j,p.d.m,p.d.a,p.semaine);
		else
			fprintf(g,"%s %d %s %.2f %d %d %d %d\n",p.id,u.repas,u.menu,u.dechet,p.d.j,p.d.m,p.d.a,p.semaine);
	}
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Menu est bien modifié !");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
	fclose(f);
	fclose(g);
remove(fname);
rename("dump.txt",fname);
}
}

void afficher(GtkWidget *liste, char *fname)
{
menu p;
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
gchar date_menu[50], dechet[10], repas[20], semaine[100];
FILE *f;


store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" ID", renderer,"text",ID, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" Repas", renderer,"text",REPAS, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" Menu", renderer,"text",MENU, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" Déchets", renderer,"text",DECHET, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_resizable(column,TRUE);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" Date", renderer,"text",DATE, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

        renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes(" Semaine", renderer,"text",SEMAINE, NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);




store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f=fopen(fname,"r");
if(f!=NULL)

{ f = fopen(fname,"a+");
		while(fscanf(f,"%s %d %s %f %d %d %d %d\n",p.id,&(p.repas),p.menu,&(p.dechet),&(p.d.j),&(p.d.m),&(p.d.a),&(p.semaine))!=EOF)
	{
sprintf(repas,p.repas==0?"Petit déjeuner":p.repas==1?"Déjeuner":"Diner");
sprintf(dechet,"%.2f",p.dechet);
sprintf(date_menu,"%d/%d/%d",p.d.j,p.d.m,p.d.a);
sprintf(semaine,"%d",p.semaine);
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,ID,p.id,REPAS,repas,MENU,p.menu,DECHET,dechet,DATE,date_menu,SEMAINE,semaine,-1);
	}
	fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
gtk_tree_view_set_enable_search(GTK_TREE_VIEW(liste),TRUE);
}

void supprimer(menu u, char *fname)
{
menu p;
GtkWidget *pInfo;
gpointer user_data;
FILE *f, *g;
f=fopen(fname,"r");
g=fopen("dump.txt","w");
if(f!=NULL&&g!=NULL){
	while(fscanf(f,"%s %d %s %f %d %d %d %d\n",p.id,&(p.repas),p.menu,&(p.dechet),&(p.d.j),&(p.d.m),&(p.d.a),&(p.semaine))!=EOF)
	{
		if(strcmp(p.id,u.id)!=0)
			fprintf(g,"%s %d %s %.2f %d %d %d %d\n",p.id,p.repas,p.menu,p.dechet,p.d.j,p.d.m,p.d.a,p.semaine);
	}
	pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Menu supprimé avec succès");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
	fclose(f);
	fclose(g);
remove(fname);
rename("dump.txt",fname);
}
}

//char* meilleur_menu(char *fname)


