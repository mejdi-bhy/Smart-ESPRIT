#include <gtk/gtk.h>


void
on_buttonOk_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAnnuler_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_aff_cap1_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_aj_cap1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_md_cap_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_spp_cap1_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_rech_cap1_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_ann_suup__cap_activate              (GtkButton       *button,
                                        gpointer         user_data);

void
on_cnf_spp_cap_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_ann_md5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_moddd_cap_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_cap_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_checkbutton1_cap_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_cap_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_cap_alarments_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_ret_tach2_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_tmp_cap_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_debit_cap_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_mouvement_cap_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_fumee_cap_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_alarmei_cap_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_calcule_cap1_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_nbr_cap_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_ritty_clicked                       (GtkButton       *button,
                                        gpointer         user_data);
