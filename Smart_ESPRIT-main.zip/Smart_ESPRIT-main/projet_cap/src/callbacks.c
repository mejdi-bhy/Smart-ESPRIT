#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteur.c"

char refff[20];
char typee[20]="temperature";
int cnf;
int cnf1;

/*----------------[Ajouter]-------------------------*/
void
on_buttonOk_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
capteur c;

GtkWidget *entryreference ,*entryType ,*entryheure ,*etage  ,*valeur;
GtkWidget *fenetre_ajouter;
fenetre_ajouter=lookup_widget(button,"ajouter_cap");

GtkWidget *date;
date = lookup_widget (button ,"calendar1_cap");
entryreference=lookup_widget(button,"ref_cap");
entryType=lookup_widget(button,"comboboxentry1_cap");
entryheure=lookup_widget(button,"heure_cap");

etage=lookup_widget(button,"spinbutton1_cap");
valeur=lookup_widget(button,"spinbutton2_cap");

GtkWidget *e_re_cap,*e_type_cap,*e_hr_cap,*e_conf_cap;


int o=0;

e_re_cap=lookup_widget(button,"e_ref_cap");
e_type_cap=lookup_widget(button,"e_type_cap");
e_hr_cap=lookup_widget(button,"e_hr_cap");
e_conf_cap=lookup_widget(button,"e_cnf_cap");



 strcpy(c.reference,gtk_entry_get_text(GTK_ENTRY(entryreference) ) );
 strcpy(c.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entryType)));
 strcpy(c.heure,gtk_entry_get_text(GTK_ENTRY(entryheure) ) );

 c.etage=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(etage));
 c.valeur=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(valeur));

gtk_calendar_get_date (GTK_CALENDAR(date),
                       &c.dt.annee,
                       &c.dt.mois,
                       &c.dt.jour);
c.dt.mois=c.dt.mois+1;

if (strcmp(c.reference,"")==0)
{o=1;
gtk_widget_show(e_re_cap);
}
else 
{o=0;
gtk_widget_hide(e_re_cap);
}

if (strcmp(c.type,"")==0)
{o=1;
gtk_widget_show(e_type_cap);
}
else 
{o=0;
gtk_widget_hide(e_type_cap);
}

if (strcmp(c.heure,"")==0)
{o=1;
gtk_widget_show(e_hr_cap);
}
else 
{o=0;
gtk_widget_hide(e_hr_cap);
}

if (cnf==0)
{
gtk_widget_show(e_conf_cap);
}
else 
{
gtk_widget_hide(e_conf_cap);
}


if (o==0 && cnf==1){

ajouter_capteur(c);
GtkWidget *ajouter_cap;
ajouter_cap=lookup_widget(button,"ajouter_cap");
gtk_widget_destroy(ajouter_cap);
GtkWidget *afficher_cap;
afficher_cap = create_afficher_cap ();
  gtk_widget_show (afficher_cap);
cnf=0;
}
}
/*-----------------[Annuler Ajouter]----------------------*/
void
on_buttonAnnuler_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter_cap;
ajouter_cap=lookup_widget(button,"ajouter_cap");
gtk_widget_destroy(ajouter_cap);
GtkWidget *afficher_cap;
afficher_cap = create_afficher_cap ();
  gtk_widget_show (afficher_cap);
}

/*---------------------[Treeview]------------------------*/
void
on_aff_cap1_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1_cap;
GtkWidget *afficher_cap;
afficher_cap=lookup_widget(button,"afficher_cap");
treeview1_cap=lookup_widget(afficher_cap,"treeview1_cap");
afficher_capteur(treeview1_cap);
}

/*-----------------------------[de treeview -> Ajouter]---------------*/
void
on_aj_cap1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *afficher_cap;
afficher_cap=lookup_widget(button,"afficher_cap");
gtk_widget_destroy(afficher_cap);
GtkWidget *ajouter_cap;
ajouter_cap = create_ajouter_cap ();
  gtk_widget_show (ajouter_cap);

}

/*-----------------------[Modification]----------------------*/
void
on_md_cap_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *afficher_cap;
afficher_cap=lookup_widget(button,"afficher_cap");
gtk_widget_destroy(afficher_cap);
GtkWidget *modifeir_cap;
modifeir_cap = create_modifier_cap ();
  gtk_widget_show (modifeir_cap);


char ref[30];
char type[30];
char hr[30];
char etage[30];
char valeur[30];
char jj[30];
char mm[30];
char aa[30];
char y[30]="";

FILE *f;

f=fopen("fichier.txt","r");







while(fscanf(f, "%s %s %s %s %s %s %s %s \n",ref,type,hr,etage,valeur,jj,mm,aa)!=EOF){
 if (strcmp(refff,ref)==0){
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(modifeir_cap,"heure_cap1")),hr);
                
        

}}

}

/*---------------------[Supprimer]---------------------*/
void
on_spp_cap1_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *afficher_cap;
afficher_cap=lookup_widget(button,"afficher_cap");

GtkWidget *supprimer_cap;
supprimer_cap = create_supprimer_cap ();
  gtk_widget_show (supprimer_cap);
}

/*--------------------[Recherche]---------------------*/
void
on_rech_cap1_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *cherch;
char ch[20];
GtkWidget *treeview1_cap;
GtkWidget *afficher_cap;
afficher_cap=lookup_widget(button,"afficher_cap");

treeview1_cap=lookup_widget(afficher_cap,"treeview1_cap");
cherch = lookup_widget (button ,"entre_rech_cap");
strcpy(ch, gtk_entry_get_text(GTK_ENTRY(cherch)));
 rechercher_capteur(treeview1_cap,ch);
}

/*----------------------[Annuler supp]-----------------------*/
void
on_ann_suup__cap_activate              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter_cap;
ajouter_cap=lookup_widget(button,"supprimer_cap");
gtk_widget_destroy(ajouter_cap);
GtkWidget *afficher_cap;

  gtk_widget_show (afficher_cap);

}

/*--------------------[Confirmation supp]------------------------*/
void
on_cnf_spp_cap_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
supprimer_capteur(refff);
GtkWidget *supprimer_cap;
supprimer_cap=lookup_widget(button,"supprimer_cap");
gtk_widget_destroy(supprimer_cap);
GtkWidget *afficher_cap;

  gtk_widget_show (afficher_cap);
}

/*-------------------------[Annuler modification]-------------------*/
void
on_ann_md5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter_cap;
ajouter_cap=lookup_widget(button,"modifier_cap");
gtk_widget_destroy(ajouter_cap);
GtkWidget *afficher_cap;
afficher_cap = create_afficher_cap ();
  gtk_widget_show (afficher_cap);

}

/*----------------[Treeview + select par type / ref / etage  + modification page]-------------------*/
void
on_moddd_cap_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
capteur c;

GtkWidget *entryreference ,*entryType ,*entryheure ,*etage  ,*valeur;
GtkWidget *fenetre_ajouter;


GtkWidget *date;

entryType=lookup_widget(button,"comboboxentry2_cap");
entryheure=lookup_widget(button,"heure_cap1");
valeur=lookup_widget(button,"spinbutton3_cap");

GtkWidget *e_re_cap,*e_type_cap,*e_hr_cap,*e_conf_cap;


int o=0;  // controle de saisie

e_conf_cap=lookup_widget(button,"e_cnf_cap1");
e_type_cap=lookup_widget(button,"e_type_cap1");
e_hr_cap=lookup_widget(button,"e_hr_cap1");


 strcpy(c.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entryType)));
 strcpy(c.heure,gtk_entry_get_text(GTK_ENTRY(entryheure) ) );

 c.valeur=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(valeur));




if (strcmp(c.type,"")==0)
{o=1;
gtk_widget_show(e_type_cap);
}
else 
{o=0;
gtk_widget_hide(e_type_cap);
}

if (strcmp(c.heure,"")==0)
{o=1;
gtk_widget_show(e_hr_cap);
}
else 
{o=0;
gtk_widget_hide(e_hr_cap);
}

if (cnf1==0)
{
gtk_widget_show(e_conf_cap);
}
else 
{
gtk_widget_hide(e_conf_cap);
}

if (o==0 && cnf1==1){


modifier_capteur(refff,c);
GtkWidget *ajouter_cap;
ajouter_cap=lookup_widget(button,"modifier_cap");
gtk_widget_destroy(ajouter_cap);
GtkWidget *afficher_cap;
afficher_cap = create_afficher_cap ();
  gtk_widget_show (afficher_cap);
cnf1=0;

}
/*--------------l'ajout d'une fenetre pour confiermer votre modification  ---------------------------*/
  GdkPixbuf *pixbuf = gdk_pixbuf_new_from_file("Login.png", NULL);

  GtkWidget *dialog = gtk_about_dialog_new();
  gtk_about_dialog_set_name(GTK_ABOUT_DIALOG(dialog), "Modifier");
  gtk_about_dialog_set_version(GTK_ABOUT_DIALOG(dialog), "avec succés "); 
  gtk_about_dialog_set_comments(GTK_ABOUT_DIALOG(dialog), 
     "vous pouvez voir votre modification sur l'affichage  .");
  gtk_about_dialog_set_logo(GTK_ABOUT_DIALOG(dialog), pixbuf);
  g_object_unref(pixbuf), pixbuf = NULL;
  gtk_dialog_run(GTK_DIALOG (dialog));
  gtk_widget_destroy(dialog);
/*---------------------------------------------*/}

/*-----------------[Treeview]----------------*/
void
on_treeview1_cap_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* ref;
	gchar* type;
	gchar* hr;
	gchar* etage;
	gchar* valeur;
	gchar* date;
	
	

	GtkTreeModel *model =gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter , path))
	{ 
	  gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0 , &ref, 1, &type,2,&hr,3,&etage,4,&valeur,5,&date,-1);
	strcpy(refff,ref);
	
	}
}

/****----------------[Check Buttton]----------------**/
void
on_checkbutton1_cap_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
cnf=1;
}


void
on_checkbutton2_cap_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
cnf1=1;
}

/*------------------[Alarme comparaison Min/Max]-------------------*/
void
on_cap_alarments_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *min;
GtkWidget *max;
min=lookup_widget(button,"spinbutton1_min");
max=lookup_widget(button,"spinbutton2_max");

int min1;
min1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(min));
int max1;
max1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(max));

GtkWidget *treeview2_cap;
GtkWidget *tache2_cap;
tache2_cap=lookup_widget(button,"tache2_cap");
treeview2_cap=lookup_widget(tache2_cap,"treeview2_cap");
afficher_alarment(treeview2_cap,typee,min1,max1);
}

/*----------------[ ouvrire alarme window]----------------------*/
void
on_ret_tach2_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter_cap;
ajouter_cap=lookup_widget(button,"tache2_cap");
gtk_widget_destroy(ajouter_cap);
GtkWidget *afficher_cap;
afficher_cap = create_afficher_cap ();
  gtk_widget_show (afficher_cap);
}

/*------------------[Toggle button]---------------------------**/
void
on_tmp_cap_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
strcpy(typee,"temperature");

}


void
on_debit_cap_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
strcpy(typee,"debit");
}


void
on_mouvement_cap_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
strcpy(typee,"mouvement");
}


void
on_fumee_cap_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
strcpy(typee,"fumee");
}

/*-----------------[Affichage de Treeview]-----------------------*/
void
on_alarmei_cap_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter_cap;
ajouter_cap=lookup_widget(button,"afficher_cap");
gtk_widget_destroy(ajouter_cap);
GtkWidget *afficher_cap;
afficher_cap = create_tache2_cap ();
  gtk_widget_show (afficher_cap);
}


void
on_calcule_cap1_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter_cap;
ajouter_cap=lookup_widget(button,"afficher_cap");
gtk_widget_destroy(ajouter_cap);
GtkWidget *afficher_cap;
afficher_cap = create_calcul_cap ();
  gtk_widget_show (afficher_cap);
}


void
on_nbr_cap_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
int nnn;
char a[200];
int s;
GtkWidget *aaa;
aaa=lookup_widget(button,"spinbutton111_cap");
nnn=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(aaa));
GtkWidget *nbr_ettt;
nbr_ettt=lookup_widget(button,"label_nbr_cap");


s = stat(nnn);
sprintf(a,"%d",s);
gtk_label_set_text(GTK_LABEL(nbr_ettt),a);
}


void
on_ritty_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter_cap;
ajouter_cap=lookup_widget(button,"calcul_cap");
gtk_widget_destroy(ajouter_cap);
GtkWidget *afficher_cap;
afficher_cap = create_afficher_cap ();
  gtk_widget_show (afficher_cap);
}

