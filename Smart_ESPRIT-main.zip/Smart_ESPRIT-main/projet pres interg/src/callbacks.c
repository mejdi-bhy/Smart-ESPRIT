#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonctions.h"

void
on_buttonbhyaffichera_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *bhy_afficher;
GtkWidget *treeview1bhy;
bhy_afficher=lookup_widget(objet_graphique,"bhy_afficher");
bhy_afficher=create_bhy_afficher();
gtk_widget_show(bhy_afficher);
treeview1bhy=lookup_widget(bhy_afficher,"treeview1bhy");
bhyAfficher("liste_ajouter.txt",treeview1bhy);
}




void
on_buttonbhyAjouter_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* input1;
GtkWidget* input2;
GtkWidget* input3;
GtkWidget* input4;
GtkWidget* input5;
GtkWidget* input6;
GtkWidget* input7;
GtkWidget* input8;
GtkWidget* input9;

input1= lookup_widget(objet_graphique, "entrybhyidentifianta");
input2= lookup_widget(objet_graphique, "entrybhynoma");
input3= lookup_widget(objet_graphique, "comboboxentrybhytypea");
input4= lookup_widget(objet_graphique, "entrybhyfournisseura");
input5= lookup_widget(objet_graphique, "spinbuttonbhycouta");
input6= lookup_widget(objet_graphique, "entrybhyquantitea");
input7= lookup_widget(objet_graphique, "spinbuttonbhyjoura");
input8= lookup_widget(objet_graphique, "spinbuttonbhymoisa");
input9= lookup_widget(objet_graphique, "spinbuttonbhyanneea");

char i [100];
char n [100];
char t [100];
char f [100];
int c;
char q [100];
int j ;
int m;
int a;
char sc [100];
char sj [100];
char sm [100];
char sa [100];
char dn [100];
int unique;

strcpy(i,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(n,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(f,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(q,gtk_entry_get_text(GTK_ENTRY(input6)));

strcpy(t,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));

c=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
sprintf(sc,"%d",c);
j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9));
sprintf(sj,"%d",j);
sprintf(sm,"%d",m);
sprintf(sa,"%d",a);
strcat(sj,"/");
strcat(sm,"/");
strcat(sm,sa);
strcat(sj,sm);
strcpy(dn,sj);

information inf;
strcpy(inf.bhyidentifiant,i);
strcpy(inf.bhynom,n);
strcpy(inf.bhytype,t);
strcpy(inf.bhyfournisseur,f);
strcpy(inf.bhycout,sc);
strcpy(inf.bhyquantite,q);
strcpy(inf.bhydate,dn);

if((strlen(inf.bhyidentifiant)==0)||(strlen(inf.bhynom)==0)||(strlen(inf.bhyfournisseur)==0)||(strlen(inf.bhyquantite)==0))
{
GtkWidget *bhyerreur;
bhyerreur=create_bhyerreur();
gtk_widget_show(bhyerreur);
}
else
{
unique=is_unique("liste_ajouter.txt",inf.bhyidentifiant);
if((unique==-1))
{
GtkWidget *bhyerreur;
bhyerreur=create_bhyerreur();
gtk_widget_show(bhyerreur);
}
else
{
if((unique==1)&&(strlen(inf.bhyidentifiant)!=0)&&(strlen(inf.bhynom)!=0)&&(strlen(inf.bhyfournisseur)!=0)&&(strlen(inf.bhyquantite)!=0))
{
bhyajouter("liste_produit.txt",inf);

GtkWidget *input;
GtkWidget *bhysucc;
bhysucc=lookup_widget(objet_graphique,"bhysucc");
bhysucc=create_bhysucc();
gtk_widget_show(bhysucc);
}
}
}



/*
bhyajouter("liste_produit.txt",inf);

GtkWidget *input;
GtkWidget *bhysucc;
bhysucc=lookup_widget(objet_graphique,"bhysucc");
bhysucc=create_bhysucc();
gtk_widget_show(bhysucc);
*/
}

information i;
void
on_treeview1bhy_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *identifiant;
gchar *nom;
gchar *type;
gchar *fournisseur;
gchar *cout;
gchar *quantite;
gchar *date;
gchar *stock;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&identifiant,1,&nom,2,&type,3,&fournisseur,4,&cout,5,&quantite,6,&date,7,&stock,-1);
strcpy(i.bhyidentifiant,identifiant);
strcpy(i.bhynom,nom);
strcpy(i.bhytype,type);
strcpy(i.bhyfournisseur,fournisseur);
strcpy(i.bhycout,cout);
strcpy(i.bhyquantite,quantite);
strcpy(i.bhydate,date);
strcpy(i.bhystock,stock);
}
}

void
on_buttonbhyactualiser_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *bhy_afficher,*w1;
GtkWidget *treeview1bhy;
w1=lookup_widget(objet_graphique,"bhy_afficher");
bhy_afficher=create_bhy_afficher();
gtk_widget_show(bhy_afficher);
gtk_widget_hide(w1);
treeview1bhy=lookup_widget(bhy_afficher,"treeview1bhy");
bhyAfficher("liste_ajouter.txt",treeview1bhy);
}


void
on_buttonbhyretour_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *gerer_le_stock,*bhy_afficher;
bhy_afficher=lookup_widget(objet_graphique,"bhy_afficher");
gtk_widget_destroy(bhy_afficher);

gtk_widget_show(gerer_le_stock);
}


void
on_buttonbhyajouter_aff_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *gerer_le_stock,*bhy_afficher;
bhy_afficher=lookup_widget(objet_graphique,"bhy_afficher");
gtk_widget_destroy(bhy_afficher);
gerer_le_stock=create_gerer_le_stock();
gtk_widget_show(gerer_le_stock);
}


void
on_buttonbhysupprimer_aff_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
bhysupprimer("liste_ajouter.txt",i.bhyidentifiant);
}


void
on_buttonbhymodifier_aff_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input;
GtkWidget *bhy_modifier;
bhy_modifier=lookup_widget(objet_graphique,"bhy_modifier");
bhy_modifier=create_bhy_modifier();
gtk_widget_show(bhy_modifier);

}


void
on_buttonbhyrechercher_aff_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* input;
char c [100];
input= lookup_widget(objet_graphique, "entrybhyidentifiant_aff");
strcpy(c,gtk_entry_get_text(GTK_ENTRY(input)));
bhyrecherche("liste_ajouter.txt",c);
GtkWidget *bhy_afficher,*w1;
GtkWidget *treeview1bhy;
w1=lookup_widget(objet_graphique,"bhy_afficher");
bhy_afficher=create_bhy_afficher();
gtk_widget_show(bhy_afficher);
gtk_widget_hide(w1);
treeview1bhy=lookup_widget(bhy_afficher,"treeview1bhy");
bhyAfficher("liste_recherchee.txt",treeview1bhy);
}

int choix[10]={0,0,0};
void
on_checkbuttonen_stock_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix[0]=1;
}


void
on_checkbuttonalert_rupture_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix[1]=1;
}


void
on_checkbuttonrupture_stock_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix[2]=1;
}


void
on_buttonrecherche_stock_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
if ((choix[0]==0)&&(choix[1]==0)&&(choix[2]==1))
{ char c [100];
strcpy(c,"en_rupture_stock");
recherche_stock ("liste_ajouter.txt",c);
GtkWidget *bhy_afficher,*w1;
GtkWidget *treeview1bhy;
w1=lookup_widget(objet_graphique,"bhy_afficher");
bhy_afficher=create_bhy_afficher();
gtk_widget_show(bhy_afficher);
gtk_widget_hide(w1);
treeview1bhy=lookup_widget(bhy_afficher,"treeview1bhy");
bhyAfficher("liste_recherchee_stock.txt",treeview1bhy);
choix[0]=0;
choix[1]=0;
choix[2]=0;
}
else if ((choix[0]==0)&&(choix[1]==1)&&(choix[2]==0))
{
char c [100];
strcpy(c,"alert_de_repture");
recherche_stock ("liste_ajouter.txt",c);
GtkWidget *bhy_afficher,*w1;
GtkWidget *treeview1bhy;
w1=lookup_widget(objet_graphique,"bhy_afficher");
bhy_afficher=create_bhy_afficher();
gtk_widget_show(bhy_afficher);
gtk_widget_hide(w1);
treeview1bhy=lookup_widget(bhy_afficher,"treeview1bhy");
bhyAfficher("liste_recherchee_stock.txt",treeview1bhy);
choix[0]=0;
choix[1]=0;
choix[2]=0;
}

else if ((choix[0]==1)&&(choix[1]==0)&&(choix[2]==0))
{
char c [100];
strcpy(c,"en_stock");
recherche_stock ("liste_ajouter.txt",c);
GtkWidget *bhy_afficher,*w1;
GtkWidget *treeview1bhy;
w1=lookup_widget(objet_graphique,"bhy_afficher");
bhy_afficher=create_bhy_afficher();
gtk_widget_show(bhy_afficher);
gtk_widget_hide(w1);
treeview1bhy=lookup_widget(bhy_afficher,"treeview1bhy");
bhyAfficher("liste_recherchee_stock.txt",treeview1bhy);
choix[0]=0;
choix[1]=0;
choix[2]=0;
}
else if ((choix[0]==1)&&(choix[1]==1)&&(choix[2]==1))
{
GtkWidget *bhy_afficher,*w1;
GtkWidget *treeview1bhy;
w1=lookup_widget(objet_graphique,"bhy_afficher");
bhy_afficher=create_bhy_afficher();
gtk_widget_show(bhy_afficher);
gtk_widget_hide(w1);
treeview1bhy=lookup_widget(bhy_afficher,"treeview1bhy");
bhyAfficher("liste_ajouter.txt",treeview1bhy);
choix[0]=0;
choix[1]=0;
choix[2]=0;
}

else if ((choix[0]==0)&&(choix[1]==1)&&(choix[2]==1))
{

char c [100];
char cc [100];
strcpy(c,"en_rupture_stock");
strcpy(cc,"alert_de_repture");

FILE *f, *fw;
 char identifiant [100];
 char nom [100] ;
 char type [100];
 char fournisseur [100];
 char cout [100];
 char quantite [100];
 char date [100];
 char stock [100];

f=fopen("liste_ajouter.txt","r");
fw=fopen("liste_recherchee_stock.txt","w");
while(fscanf(f,"%s %s %s %s %s %s %s %s\n",identifiant,nom,type,fournisseur,cout,quantite,date,stock)!=EOF)
{
if((strcmp(stock,c)==0)||(strcmp(stock,cc)==0)) fprintf(fw,"%s %s %s %s %s %s %s %s\n",identifiant,nom,type,fournisseur,cout,quantite,date,stock);
}
fclose(f);
fclose(fw);

GtkWidget *bhy_afficher,*w1;
GtkWidget *treeview1bhy;
w1=lookup_widget(objet_graphique,"bhy_afficher");
bhy_afficher=create_bhy_afficher();
gtk_widget_show(bhy_afficher);
gtk_widget_hide(w1);
treeview1bhy=lookup_widget(bhy_afficher,"treeview1bhy");
bhyAfficher("liste_recherchee_stock.txt",treeview1bhy);
choix[0]=0;
choix[1]=0;
choix[2]=0;
}
else if ((choix[0]==1)&&(choix[1]==0)&&(choix[2]==1))
{

char c [100];
char cc [100];
strcpy(c,"en_stock");
strcpy(cc,"en_rupture_stock");

FILE *f, *fw;
 char identifiant [100];
 char nom [100] ;
 char type [100];
 char fournisseur [100];
 char cout [100];
 char quantite [100];
 char date [100];
 char stock [100];

f=fopen("liste_ajouter.txt","r");
fw=fopen("liste_recherchee_stock.txt","w");
while(fscanf(f,"%s %s %s %s %s %s %s %s\n",identifiant,nom,type,fournisseur,cout,quantite,date,stock)!=EOF)
{
if((strcmp(stock,c)==0)||(strcmp(stock,cc)==0)) fprintf(fw,"%s %s %s %s %s %s %s %s\n",identifiant,nom,type,fournisseur,cout,quantite,date,stock);
}
fclose(f);
fclose(fw);

GtkWidget *bhy_afficher,*w1;
GtkWidget *treeview1bhy;
w1=lookup_widget(objet_graphique,"bhy_afficher");
bhy_afficher=create_bhy_afficher();
gtk_widget_show(bhy_afficher);
gtk_widget_hide(w1);
treeview1bhy=lookup_widget(bhy_afficher,"treeview1bhy");
bhyAfficher("liste_recherchee_stock.txt",treeview1bhy);
choix[0]=0;
choix[1]=0;
choix[2]=0;
}

else if ((choix[0]==1)&&(choix[1]==1)&&(choix[2]==0))
{

char c [100];
char cc [100];
strcpy(c,"en_stock");
strcpy(cc,"alert_de_repture");

FILE *f, *fw;
 char identifiant [100];
 char nom [100] ;
 char type [100];
 char fournisseur [100];
 char cout [100];
 char quantite [100];
 char date [100];
 char stock [100];

f=fopen("liste_ajouter.txt","r");
fw=fopen("liste_recherchee_stock.txt","w");
while(fscanf(f,"%s %s %s %s %s %s %s %s\n",identifiant,nom,type,fournisseur,cout,quantite,date,stock)!=EOF)
{
if((strcmp(stock,c)==0)||(strcmp(stock,cc)==0)) fprintf(fw,"%s %s %s %s %s %s %s %s\n",identifiant,nom,type,fournisseur,cout,quantite,date,stock);
}
fclose(f);
fclose(fw);

GtkWidget *bhy_afficher,*w1;
GtkWidget *treeview1bhy;
w1=lookup_widget(objet_graphique,"bhy_afficher");
bhy_afficher=create_bhy_afficher();
gtk_widget_show(bhy_afficher);
gtk_widget_hide(w1);
treeview1bhy=lookup_widget(bhy_afficher,"treeview1bhy");
bhyAfficher("liste_recherchee_stock.txt",treeview1bhy);
choix[0]=0;
choix[1]=0;
choix[2]=0;
}
}

void
on_entrybhyidentifiantm_grab_focus     (GtkWidget       *widget,
                                        gpointer         user_data)
{
GtkWidget* widget1;
GtkWidget* widget2;
GtkWidget* widget3;
GtkWidget* widget4;
GtkWidget* widget5;
GtkWidget* widget6;
GtkWidget* widget7;
GtkWidget* widget8;
GtkWidget* widget9;
GtkWidget* widgets;
GtkWidget* widgeta;
GtkWidget* widgetr;

widget1=lookup_widget(widget, "entrybhyidentifiantm");
gtk_entry_set_text(GTK_ENTRY(widget1),i.bhyidentifiant);
widget2=lookup_widget(widget, "entrybhynomm");
gtk_entry_set_text(GTK_ENTRY(widget2),i.bhynom);
widget3= lookup_widget(widget, "comboboxentrybhytypem");
int b=0;
if(strcmp(i.bhytype,"produit1")==0)
b=0;
if(strcmp(i.bhytype,"produit2")==0)
b=1;
if(strcmp(i.bhytype,"produit3")==0)
b=2;
gtk_combo_box_set_active(GTK_COMBO_BOX(widget3),b);
widget4=lookup_widget(widget, "entrybhyfournisseurm");
gtk_entry_set_text(GTK_ENTRY(widget4),i.bhyfournisseur);
widget5=lookup_widget(widget, "entrybhyquantitem");
gtk_entry_set_text(GTK_ENTRY(widget5),i.bhyquantite);

widgets=lookup_widget(widget, "radiobuttonstockm");
widgeta=lookup_widget(widget, "radiobuttonalert");
widgetr=lookup_widget(widget, "radiobuttonrupture");
if(strcmp(i.bhystock,"en_stock")==0) gtk_toggle_button_set_active(GTK_RADIO_BUTTON(widgets),TRUE);
if(strcmp(i.bhystock,"alert_de_repture")==0) gtk_toggle_button_set_active(GTK_RADIO_BUTTON(widgeta),TRUE);
if(strcmp(i.bhystock,"en_rupture_stock")==0) gtk_toggle_button_set_active(GTK_RADIO_BUTTON(widgetr),TRUE);

widget6=lookup_widget(widget, "spinbuttonbhycout");
int o;
o=atoi(i.bhycout);
gtk_spin_button_set_value(widget6,o);

int p_occ=-1,d_occ=0;
pos_car(i.bhydate,'/',&p_occ,&d_occ);
int z;
char j [3];
for(z=0;z<p_occ;z++) j[z]=i.bhydate[z];
j[p_occ]='\0';
int zj=0;
zj=atoi(j);
widget7=lookup_widget(widget, "spinbuttonbhyjourm");
gtk_spin_button_set_value(widget7,zj);
char m [3];
for(z=p_occ+1;z<d_occ;z++) m[z-p_occ-1]=i.bhydate[z];
m[d_occ-p_occ-1]='\0';
int zm=0;
zm=atoi(m);
widget8=lookup_widget(widget, "spinbuttonbhymoism");
gtk_spin_button_set_value(widget8,zm);
char a [5];
for(z=d_occ+1;z<strlen(i.bhydate);z++) a[z-d_occ-1]=i.bhydate[z];
a[strlen(i.bhydate)-d_occ-1]='\0';
int za=0;
za=atoi(a);
widget9=lookup_widget(widget, "spinbuttonbhyanneem");
gtk_spin_button_set_value(widget9,za);



}

int e=1;
void
on_radiobuttonstockm_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))) e=0;
}


void
on_radiobuttonalert_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))) e=1;
}


void
on_radiobuttonrupture_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))) e=2;
}


void
on_buttonbhymodifier_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget* input2;
GtkWidget* input3;
GtkWidget* input4;
GtkWidget* input5;
GtkWidget* input6;
GtkWidget* input7;
GtkWidget* input8;
GtkWidget* input9;


input2= lookup_widget(objet_graphique, "entrybhynomm");
input3= lookup_widget(objet_graphique, "comboboxentrybhytypem");
input4= lookup_widget(objet_graphique, "entrybhyfournisseurm");
input5= lookup_widget(objet_graphique, "spinbuttonbhycout");
input6= lookup_widget(objet_graphique, "entrybhyquantitem");
input7= lookup_widget(objet_graphique, "spinbuttonbhyjourm");
input8= lookup_widget(objet_graphique, "spinbuttonbhymoism");
input9= lookup_widget(objet_graphique, "spinbuttonbhyanneem");


char n [100];
char t [100];
char f [100];
int c;
char q [100];
int j ;
int m;
int a;
char sc [100];
char sj [100];
char sm [100];
char sa [100];
char dn [100];
char s [100];

if (e==0) strcpy(s,"en_stock");
else if(e==1) 
strcpy(s,"alert_de_repture");
else strcpy(s,"en_rupture_stock");

strcpy(n,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(f,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(q,gtk_entry_get_text(GTK_ENTRY(input6)));

strcpy(t,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));

c=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
sprintf(sc,"%d",c);
j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9));
sprintf(sj,"%d",j);
sprintf(sm,"%d",m);
sprintf(sa,"%d",a);
strcat(sj,"/");
strcat(sm,"/");
strcat(sm,sa);
strcat(sj,sm);
strcpy(dn,sj);

information infoo;
strcpy(infoo.bhyidentifiant,i.bhyidentifiant);
strcpy(infoo.bhynom,n);
strcpy(infoo.bhytype,t);
strcpy(infoo.bhyfournisseur,f);
strcpy(infoo.bhycout,sc);
strcpy(infoo.bhyquantite,q);
strcpy(infoo.bhydate,dn);
strcpy(infoo.bhystock,s);

bhymodifier("liste_ajouter.txt",i.bhyidentifiant,infoo);
}


void
on_buttonbhyretour_succ_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *gerer_le_stock,*bhysucc;
bhysucc=lookup_widget(objet_graphique,"bhysucc");
gtk_widget_destroy(bhysucc);

gtk_widget_show(gerer_le_stock);
}


void
on_buttonbhymodretour_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *bhy_modifier,*bhy_afficher;
bhy_modifier=lookup_widget(objet_graphique,"bhy_modifier");
gtk_widget_destroy(bhy_modifier);

gtk_widget_show(bhy_afficher);
}


void
on_buttonbhyerreur_retour_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *gerer_le_stock,*bhyerreur;
bhyerreur=lookup_widget(objet_graphique,"bhyerreur");
gtk_widget_destroy(bhyerreur);

gtk_widget_show(gerer_le_stock);
}

