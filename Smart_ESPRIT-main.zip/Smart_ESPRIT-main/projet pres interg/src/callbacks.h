#include <gtk/gtk.h>


void
on_buttonbhyaffichera_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonbhyAjouter_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview1bhy_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonbhyactualiser_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonbhyretour_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonbhyajouter_aff_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonbhysupprimer_aff_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonbhymodifier_aff_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonbhyrechercher_aff_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbuttonen_stock_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonalert_rupture_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonrupture_stock_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonrecherche_stock_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_entrybhyidentifiantm_grab_focus     (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_radiobuttonstockm_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonalert_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonrupture_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonbhymodifier_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonbhyretour_succ_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonbhymodretour_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonbhyerreur_retour_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
