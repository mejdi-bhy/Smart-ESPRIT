#include <gtk/gtk.h>


void
on_login_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_inscription_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_insc_retour_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_inscri_ok_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valid_niv_etud_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_gu_ajouter_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_gu_recherche_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_gu_niv_etud_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_gu_retour_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_gu_F5_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_recherche_ok_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_ok_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rech_niveau_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supp_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_check_supp_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_check_annul_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_valid_supp_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_edit_niv_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_pw_toggled                          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_color_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_copyright_user_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_copyright_ok_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_paint_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);
