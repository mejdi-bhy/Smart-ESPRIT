#include <gtk/gtk.h>


void
on_treeview1_user_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_go_ajouter_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_go_supprimer_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_go_modifier_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_user_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_rechercher_user_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_deconn_user_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_et_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_chercher_et_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter_et_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_et_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_ajouteret_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_annuler_supp_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_conf_supp_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_et_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_et_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_auth_et_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_inns_ett_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_insc_et_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_anul_ins_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_stat_etttttt_clicked                (GtkButton       *button,
                                        gpointer         user_data);
